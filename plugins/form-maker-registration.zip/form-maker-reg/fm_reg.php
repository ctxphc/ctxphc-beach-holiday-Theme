<?php
/**
 * Formmaker Registration
 * @author         web-dorado
 * @license
 * @link            https://web-dorado.com
 *
 * @wordpress-plugin
 * Plugin Name:    Formmaker Registration
 * Plugin URI:		https://web-dorado.com/products/wordpress-form/add-ons/registration.html
 * Description:		User Registration add-on integrates with Form maker forms allowing users to create accounts at your website.
 * Version:         1.0.1
 * Author:          web-dorado
 * Author URI:      https://web-dorado.com
 * License:
 * License URI:
 */
 
define('WD_FM_REG', 	plugin_basename(__FILE__));
define('WD_FM_REG_DIR', WP_PLUGIN_DIR . "/" . plugin_basename(dirname(__FILE__)));
define('WD_FM_REG_URL', plugins_url(plugin_basename(dirname(__FILE__))));

add_action('init', 'is_main_plugin_active_reg');
add_action('WD_FM_REG_init', 'WD_FM_REG_init'); 
add_action('wp_ajax_WD_FM_REG', 'WD_FM_REG_init');

function WD_FM_REG_init()
{	
	global $wpdb;
	$formmaker_reg = "CREATE TABLE IF NOT EXISTS `" . $wpdb->prefix . "formmaker_reg` (
	  `form_id` int(11) NOT NULL,
	  `use_reg` tinyint(1) NOT NULL,
	  `username` varchar(50) NOT NULL,
	  `first_name` varchar(50) NOT NULL,
	  `last_name` varchar(50) NOT NULL,
	  `role` text NOT NULL,
	  `email` varchar(50) NOT NULL,
	  `website` varchar(50) NOT NULL,
	  `info` varchar(50) NOT NULL,
	  `password` varchar(50) NOT NULL,
	  `rep_password` varchar(50) NOT NULL
	) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
	";
	$wpdb->query($formmaker_reg);

	require_once(WD_FM_DIR . '/framework/WDW_FM_Library.php');
	require_once('controller.php');

	$reg	=	new WD_FM_REG_controller;

	$task	=	WDW_FM_Library::get("addon_task");
	$view	=	WDW_FM_Library::get("addon_view");

	$reg->execute($task, $view);
}


function is_main_plugin_active_reg()
{
	include_once(ABSPATH . 'wp-admin/includes/plugin.php');
	if (!defined('WD_MAIN_FILE') or !is_plugin_active(WD_MAIN_FILE)) 
	{
		add_action('admin_notices', 'admin_user_area_notice_reg');
	}
}

function admin_user_area_notice_reg() {
		echo ' <div class= "error" >
			<p> Please activate the Form Maker so that the Registration add-on starts working</p>
	  </div>';
}
