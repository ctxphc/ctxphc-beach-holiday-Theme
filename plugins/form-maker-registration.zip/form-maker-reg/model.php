<?php

/**
 *
 * Author: Sahak Sahakyan
 * Date: 6/30/15
 * Time: 2:00 PM
 */
class WD_FM_REG_model {
	static function save()
	{
		global $wpdb;
	
		$form_id = $wpdb->get_var($wpdb->prepare('SELECT form_id FROM ' . $wpdb->prefix . 'formmaker_reg WHERE form_id="%d"',  WDW_FM_Library::get('id')));
		
		if($form_id)
			$save = $wpdb->update($wpdb->prefix . 'formmaker_reg', array(
				  'use_reg' => WDW_FM_Library::get('use_reg'),
				  'username' =>  WDW_FM_Library::get('username'),
				  'email' =>  WDW_FM_Library::get('email'),
				  'first_name' =>  WDW_FM_Library::get('first_name'),
				  'last_name' =>  WDW_FM_Library::get('last_name'),
				  'info' =>  WDW_FM_Library::get('info'),
				  'website' =>  WDW_FM_Library::get('website'),
				  'role' =>  WDW_FM_Library::get('role'),
				  'password' =>  WDW_FM_Library::get('password')
				), array('form_id' =>  WDW_FM_Library::get('id')));
		else
			$save = $wpdb->insert($wpdb->prefix . 'formmaker_reg', array(
				  'form_id' =>  WDW_FM_Library::get('id'),
				  'use_reg' =>  WDW_FM_Library::get('use_reg'),
				  'username' =>  WDW_FM_Library::get('username'),
				  'email' =>  WDW_FM_Library::get('email'),
				  'first_name' =>  WDW_FM_Library::get('first_name'),
				  'last_name' =>  WDW_FM_Library::get('last_name'),
				  'info' =>  WDW_FM_Library::get('info'),
				  'website' =>  WDW_FM_Library::get('website'),
				  'role' =>  WDW_FM_Library::get('role'),
				  'password' =>  WDW_FM_Library::get('password')
				),array( '%s',  '%s' ));
				echo $wpdb->last_query;
	}
	
	static function get_data($id)
	{
		global $wpdb;
		
		$row = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . $wpdb->prefix . 'formmaker_reg WHERE form_id="%d"', $id));
		if($row)
			return $row;
			
		$row =(object) array(
			"form_id" => "",
			"use_reg" => 0,
			"username" => "",
			"email" => "",
			"first_name" => "",
			"last_name" => "",
			"info" => "",
			"website" => "",
			"role" => "",
			"password" => ""
		);
 
		return $row;
		
	}
	
	static function get_label_all($id)
	{
		global $wpdb;
		
		$label_all = $wpdb->get_var($wpdb->prepare('SELECT label_order_current FROM ' . $wpdb->prefix . 'formmaker WHERE id="%d"', $id));
		$label_all = explode('#****#', $label_all);
		$label_all = array_slice($label_all, 0, count($label_all) - 1);

		return $label_all;
		
	}
}
?>