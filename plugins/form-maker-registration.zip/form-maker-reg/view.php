<?php

/**
 *
 * Author: Sahak Sahakyan
 * Date: 6/30/15
 * Time: 2:00 PM
 */
class WD_FM_REG_view {

	static function load($tmpl)
	{
		$id			= WDW_FM_Library::get("current_id");
		$reg 		= WD_FM_REG_model::get_data($id);
		$label_all 	= WD_FM_REG_model::get_label_all($id);

		require_once('tmpl/'.$tmpl.'.php');
	}
}
?>