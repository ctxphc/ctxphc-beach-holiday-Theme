<?php

/**
 *
 * Author: Sahak Sahakyan
 * Date: 6/29/15
 * Time: 3:00 PM
 */
class WD_FM_REG_controller {

	function __construct() {
		require_once('model.php');
	}
	
	static function get($key, $default_value = '') 
	{
		if (isset($_GET[$key])) {
		  $value = $_GET[$key];
		}
		elseif (isset($_POST[$key])) {
		  $value = $_POST[$key];
		}
		else {
		  $value = '';
		}
		if (!$value) {
		  $value = $default_value;
		}
		
		return $value;
	}
	
	function execute($task,$view) {
		if($task)
			if(method_exists($this, $task))
				$this->$task();
		
		if($view)
			$this->view($view);		
	}
	
	function save() {
	
		WD_FM_REG_model::save();
	}

	function frontend() {
		// create user
		$form_id = WDW_FM_Library::get('form_id');
		$reg = WD_FM_REG_model::get_data($form_id);
		if($reg->use_reg)
		{
			$row =array(
				"username" => '',
				"email" => '',
				"first_name" => '',
				"last_name" => '',
				"role" => '',
				"info" => '',
				"website" => '',
				"password" => ''
			);
			
			foreach($row as $key => $tuft)
			{
				$row[$key]=$reg->$key;
				foreach($GLOBALS['fvals'] as $fval_key => $fval)
				{
					$row[$key]= str_replace($fval_key, $fval, $row[$key]);
				}
				$row[$key]= str_replace('{ip}', $_SERVER['REMOTE_ADDR'], $row[$key]);
			}
			if($row["role"]=="") $row["role"]="**conds**";
			$r = explode('**conds**', $row["role"]);
			$row["role"]=$r[0];
			$r_params=$r[1];

			
			if( strpos($r_params, "**reg_conds**")!== false)
			{
				$reg_arr = explode('**reg_conds**', $r_params);
				$reg_arr = array_slice($reg_arr, 0, count($reg_arr) - 1);
				foreach($reg_arr as $kk => $t)
				{
					$t_arr=explode('****', $t);

					if($GLOBALS['fvals']['{'.$t_arr[0].'}'] == $t_arr[1])
					{
						$row["role"]=$t_arr[2];
						break;
					}
				}
			}

			if( null == username_exists($row["username"]) ) 
			{
				$show_pass=0;
				if(!$row["password"])
				{
					$show_pass=1;
					$row["password"] = wp_generate_password( 12, false );
				}

				$userdata = array(
					'user_login'  =>  $row["username"],
					'user_pass'  =>  $row["password"],
					'user_url'    =>  $row["website"],
					'user_nicename'    =>  $row["username"],
					'user_email'    =>  $row["email"],
					'first_name'    =>  $row["first_name"],
					'last_name'    =>  $row["last_name"],
					'description'   =>  $row["info"],  
					'role'   =>  $row["role"]  
				);

				$user_id = wp_insert_user( $userdata );

				// Set the role
				/*$user = new WP_User( $user_id );
				$user->set_role( 'contributor' );*/

				// Email the user
				//wp_mail( $email_address, 'Welcome!', 'Your Password: ' . $password );
				if($show_pass) echo 'your password is '.$row["password"];

			} 
			else
				echo "eroir";
		}
	}


	function view($view) {
		require_once('view.php');
		
		WD_FM_REG_view::load($view);
	}
	
	
}
?>