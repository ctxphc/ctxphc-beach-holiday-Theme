<?php
	$filter_types=array("type_submit_reset", "type_map", "type_editor", "type_captcha", "type_recaptcha", "type_button", "type_paypal_total", "type_send_copy");
    $label_id= array();
    $label_order= array();
    $label_order_original= array();
    $label_type= array();

	$reg_select='';	
	
    foreach($label_all as $key => $label_each) {
      $label_id_each=explode('#**id**#',$label_each);
      $label_order_each=explode('#**label**#', $label_id_each[1]);
      
      if(in_array($label_order_each[1],$filter_types))
        continue;
      	
		$reg_select.='<option value="'.$label_id_each[0].'">'.$label_order_each[0].'</option>';
  
      array_push($label_id, $label_id_each[0]);
      array_push($label_order_original, $label_order_each[0]);
      $ptn = "/[^a-zA-Z0-9_]/";
      $rpltxt = "";
      $label_temp=preg_replace($ptn, $rpltxt, $label_order_each[0]);
      array_push($label_order, $label_temp);    
      array_push($label_type, $label_order_each[1]);
    }
    
    $form_fields='';
    foreach($label_id as $key => $lid) {
      $form_fields.='<a onclick="insert_field('.$lid.'); jQuery(\'#fieldlist\').hide();" style="display:block; text-decoration:none;">'.$label_order_original[$key].'</a>';
    }
	$user_fields = array("ip"=>"Submitter's IP");
	foreach($user_fields as $user_key=>$user_field) {
		$form_fields.='<a onclick="insert_field(\''.$user_key.'\'); jQuery(\'#fieldlist\').hide();" style="display:block; text-decoration:none;">'.$user_field.'</a>';
	}
?>
	<style>
	#fieldlist {
		position: absolute;
		width:200px;
		background: #fff;
		border: solid 1px #c7c7c7;
		top: 0;
		left: 0;
		z-index: 1000;
	}
	#fieldlist a {
		padding: 5px;
		cursor:pointer;
		overflow: hidden;
		white-space: nowrap;
		text-overflow: ellipsis;
	}
	#fieldlist a:hover {
		background: #ccc;
	}

	</style>
	<fieldset id="WD_FM_REG_fieldset" class="adminform fm_fieldset_deactive">
        <legend style="color:#0B55C4;font-weight: bold;">Registration</legend>
		<table class="admintable">
			<tr valign="top">
				<td class="fm_options_label">
					<label >Use Wordpress Registration Integration?</label>
				</td>
				<td class="fm_options_value" >
					<input type="radio" name="use_reg" id="use_regyes" value="1" <?php if($reg->use_reg==1 ) echo "checked" ?> /> <label for="use_regyes">Yes</label>
					<input type="radio" name="use_reg" id="use_regno" value="0"  <?php if($reg->use_reg==0 ) echo "checked"?> /> <label for="use_regno">No</label>
				</td>
			</tr>
			<?php 
				$reg_params		 = array( 'username', 'password', 'email', 'first_name', 'last_name', 'role', 'info', 'website'); 
				$reg_params_name = array( 'Username (required)', 'Password', 'E-mail', 'First Name', 'Last Name', 'Role', 'Biographical Info', 'Website'); 
			
				foreach($reg_params as $key => $reg_param)
					if($reg_param!="role")
					{
						echo '					<tr valign="top">
					<td class="fm_options_label"><label>'.$reg_params_name[$key].'</label></td>
					<td class="fm_options_value" >
						<input type="text" id="'.$reg_param.'" name="'.$reg_param.'" style="width: 200px;" value="'.$reg->$reg_param.'" />
					</td>
					</tr>';
					}
					else
					{
						if( !$reg->role)  $reg->role="**conds**";
						$r = explode('**conds**', $reg->role);
						$r_prim=$r[0];
						$reg->role=$r[1];
						$all_roles=get_editable_roles();
						
						$roles='<option value="">Select Role</option>';
						foreach($all_roles as $key2 => $all_role)
							$roles.= '<option value="'.$key2.'">'.$key2.'</option>';

						$reg_conds="";
						if( strpos($reg->role, "**reg_conds**")!== false)
						{
							$reg_arr = explode('**reg_conds**', $reg->role);
							$reg_arr = array_slice($reg_arr, 0, count($reg_arr) - 1);

							foreach($reg_arr as $kk => $t)
							{
								$t_arr=explode('****', $t);

								$reg_conds.='<div class="conds">If <select class="cond_sel_field" id="cond'.$kk.'_1"><option value="">Select field</option>'.$reg_select.'</select> equals to <input type="text" class="cond_if" value="'.$t_arr[1].'"/> than set role <select class="cond_role" id="cond'.$kk.'_2">'.$roles.'</select> <img src="'. WD_FM_URL.'/images/delete.png" onclick="delete_cond(this)" style="vertical-align: middle;"> </div>
								<script>jQuery("#cond'.$kk.'_1").val("'.$t_arr[0].'");jQuery("#cond'.$kk.'_2").val("'.$t_arr[2].'");</script>
								';
							}
						}
						
						echo '
					<tr valign="top">
						<td class="fm_options_label"><label>'.$reg_params_name[$key].'</label></td>
						<td class="fm_options_value" id="role_params" >
							<select id="'.$reg_param.'" name="'.$reg_param.'" style="width: 200px;" >'.$roles.'</select> Or <a href="javascript:add_role_cond()">Add Condition</a>
							'.$reg_conds.'
					</td>
					</tr>
					<script>jQuery("#'.$reg_param.'").val("'.$r_prim.'");</script>

					';
						
					}
				
			?>						
		</table>

	    <div id="fieldlist" style="display: none;">
        <?php echo $form_fields; ?>
        </div>

	</fieldset>
		<script>
			jQuery('#adminForm').submit(function(){
				if(jQuery('#task').val()=="cancel_options")
					return true;
					
				reg_conds=jQuery("#role").val()+"**conds**";
				if(!jQuery("#username").val() && jQuery("#use_regyes").is(':checked'))
				{
					alert("Username is required!");
					return false;
				}
				
				jQuery(".conds").each(function(){

					reg_conds+=jQuery(this).find(".cond_sel_field").val()+"****"+jQuery(this).find(".cond_if").val()+"****"+jQuery(this).find(".cond_role").val()+"**reg_conds**"
				});
				
				jQuery.ajax({
					  url: '<?php echo add_query_arg(array('action' => 'WD_FM_REG', 'addon_task' => 'save', 'id' => $id), admin_url('admin-ajax.php')); ?>&'+ jQuery('#WD_FM_REG_fieldset').serialize() + ( reg_conds!="" ? "&role="+reg_conds+"&" : ""),
					  async : false
					});

				});
			
			jQuery('html').click(function() {
			  if(jQuery("#fieldlist").css('display')=="block") {
				jQuery("#fieldlist").hide();
			  }
			});
			jQuery('#WD_FM_REG_fieldset').on('click', 'input[type="text"]',function(event) {
			  event.stopPropagation();
			  jQuery("#fieldlist").css("top",jQuery(this).position().top+jQuery(this).height()+9);
			  jQuery("#fieldlist").css("left",jQuery(this).position().left);
			  jQuery("#fieldlist").slideDown('fast');
			  selected_field=this;
			});
			
			jQuery('#fieldlist').click(function(event){
			  event.stopPropagation();
			});
			
			function insert_field(myValue) {
				if(!selected_field)
				  return;
				myField=selected_field;        
				if (document.selection) {
				  myField.focus();      
				  sel = document.selection.createRange();    
				  sel.text = myValue;    
				}    
				else {
				  if (myField.selectionStart || myField.selectionStart == '0') {
					var startPos = myField.selectionStart;       
					var endPos = myField.selectionEnd;      
					myField.value = myField.value.substring(0, startPos)           
					+  "{"+myValue+"}"        
					+ myField.value.substring(endPos, myField.value.length);   
				  }
				 else {
				  myField.value += "{"+myValue+"}";    
				 }
				}
			}
			
			function add_role_cond()
			{
				jQuery("#role_params").append('<div class="conds">If <select class="cond_sel_field"><option value="">Select field</option><?php echo $reg_select ?></select> equals to <input type="text" class="cond_if"/> than set role <select class="cond_role"><?php echo $roles ?></select> <img src="<?php echo WD_FM_URL ?>/images/delete.png" onclick="delete_cond(this)" style="vertical-align: middle;"> </div>');
			}

			function delete_cond(x)
			{
				jQuery(x).parent().remove();
			}
		</script>