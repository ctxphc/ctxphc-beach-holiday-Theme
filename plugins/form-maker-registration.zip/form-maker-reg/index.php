<?php

require_once('controller.php');

$reg	=	new WD_FM_REG_controller;

$task	=	$reg->get("addon_task");
$view	=	$reg->get("addon_view");

if(isset($fvals))
$GLOBALS['fvals'] = $fvals;

$reg->execute($task, $view);

?>
