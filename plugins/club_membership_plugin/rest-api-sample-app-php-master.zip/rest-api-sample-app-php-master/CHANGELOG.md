# CHANGELOG


## V1.1.0 (March 07, 2013)
    
    - Upgrading to SDK V0.7.x


## V1.0.0 (March 07, 2013)
    
    - Initial release
    