<div class='navbar navbar-fixed-bottom' id='footer'>
	<div class='navbar-inner'>
		<div class='container'>
			<p class='pull-right'>Powered by <a href="https://github.com/paypal/PayPal-PHP-SDK" >PayPal REST APIs</a></p>
		</div>
	</div>
</div>
