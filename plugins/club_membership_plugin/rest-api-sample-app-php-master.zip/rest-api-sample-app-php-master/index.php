<?php
header('Location: app/index.php');
exit;